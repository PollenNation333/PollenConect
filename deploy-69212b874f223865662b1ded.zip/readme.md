# Pollen Nation — Loading Screen (v15: v10 + reveal 2s early)
- Same smooth v10 flight (4.8s cubic-bezier(.15,.9,.25,1)).
- Bee + flowerball disappear and final logo fades in **2 seconds earlier** than the end.
- 3 tall bounces before flight.
